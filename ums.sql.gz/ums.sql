-- phpMyAdmin SQL Dump
-- version 4.1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Mar 05, 2014 at 02:42 PM
-- Server version: 5.6.15
-- PHP Version: 5.3.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lr`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tl_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iso_code` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `landian` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_sym` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel_prefix` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `charset` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `permissions` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `permissions`) VALUES
(1, 'Type 1 User', ''),
(2, 'Manager', '{"manager": 1,"sales": 1,"type2": 1}'),
(3, 'Sales', '{"sales": 1,"type2": 1}'),
(4, 'Type 2 User', '{"type2": 1}');

-- --------------------------------------------------------

--
-- Table structure for table `salts`
--

CREATE TABLE IF NOT EXISTS `salts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `record_status` int(11) DEFAULT NULL,
  `prefix` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suffix` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_datetime` datetime DEFAULT NULL,
  `to_datetime` datetime DEFAULT NULL,
  `method` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `salts`
--

INSERT INTO `salts` (`id`, `record_status`, `prefix`, `suffix`, `from_datetime`, `to_datetime`, `method`) VALUES
(1, NULL, 'pre', 'suf', '2014-02-10 12:23:53', '2014-02-10 15:40:26', 'default'),
(11, NULL, 'pre1', 'suf1', '2014-02-10 15:40:26', '2014-02-10 15:41:03', 'default'),
(12, NULL, 'pre2', 'suf2', '2014-02-10 15:41:03', NULL, 'default');

-- --------------------------------------------------------

--
-- Table structure for table `site_data`
--

CREATE TABLE IF NOT EXISTS `site_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verify` int(11) NOT NULL DEFAULT '0',
  `verify_email` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `welcome` int(11) NOT NULL DEFAULT '0',
  `welcome_email` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `site_data`
--

INSERT INTO `site_data` (`id`, `name`, `description`, `logo`, `verify`, `verify_email`, `welcome`, `welcome_email`) VALUES
(1, 'This is my site', 'This is my cool new site', NULL, 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` bigint(20) DEFAULT NULL,
  `fullname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shortname` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mnemonic` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_session`
--

CREATE TABLE IF NOT EXISTS `users_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `hash` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

CREATE TABLE IF NOT EXISTS `user_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(127) NOT NULL,
  `current_password` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `current_passdate` datetime NOT NULL,
  `last_password` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_passdate` datetime DEFAULT NULL,
  `password_status` int(11) NOT NULL DEFAULT '1',
  `salt` binary(32) NOT NULL,
  `account_status` int(1) NOT NULL DEFAULT '0',
  `regdatetime` datetime NOT NULL,
  `user_group` bigint(11) NOT NULL DEFAULT '1',
  `reset` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_time` datetime DEFAULT NULL,
  `verification_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `verification_date` datetime DEFAULT NULL,
  `accept_cookies` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=109 ;

--
-- Dumping data for table `user_access`
--

INSERT INTO `user_access` (`id`, `email`, `current_password`, `current_passdate`, `last_password`, `last_passdate`, `password_status`, `salt`, `account_status`, `regdatetime`, `user_group`, `reset`, `reset_time`, `verification_code`, `verification_date`, `accept_cookies`) VALUES
(98, 'admin@admin.com', '1164aeb76650571c3ff82d0b96f3ed17a35601acc0520230c93b6677f173801d', '2014-02-04 14:07:41', NULL, NULL, 1, '6$����\rym�>1�U�3+�ئ�dr���}��', 1, '2014-02-04 14:07:41', 2, NULL, NULL, NULL, '2014-02-04 14:07:41', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE IF NOT EXISTS `user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `regdatetime` datetime NOT NULL,
  `record_status` int(11) DEFAULT NULL,
  `address_type` int(11) DEFAULT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `house` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `district` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` bigint(20) DEFAULT NULL,
  `postcode_major` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode_minor` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` bigint(20) DEFAULT NULL,
  `gender` tinyint(1) DEFAULT NULL,
  `birth` date DEFAULT NULL,
  `nationality` bigint(20) DEFAULT NULL,
  `house_telno` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_telno` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_telno` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=109 ;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `user_id`, `regdatetime`, `record_status`, `address_type`, `first_name`, `last_name`, `house`, `street`, `district`, `city`, `state`, `postcode_major`, `postcode_minor`, `country`, `gender`, `birth`, `nationality`, `house_telno`, `mobile_telno`, `work_telno`, `image`) VALUES
(98, 98, '2014-02-04 14:07:41', NULL, NULL, 'Admin', 'Admin', NULL, NULL, NULL, 'Baldwin', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
